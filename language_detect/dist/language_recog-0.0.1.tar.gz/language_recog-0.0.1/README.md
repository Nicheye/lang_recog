# `language_recog`

The `language_recog` is a simple package for recognizing different languages. 

from language_detect.src.reco_lang.get_lang import GetLang